package com.example.campominadokotlinolivier

import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.roundToInt // Importação necessária para corrigir o erro do Math.round

class MainActivity : AppCompatActivity() {

    companion object {
        private const val ROWS = 10
        private const val COLS = 10
        private const val MINE_PERCENTAGE = 0.15 // 15% de minas

        // Chaves para o SharedPreferences
        private const val PREF_NAME = "CampoMinadoPrefs"
        private const val KEY_MENOR_TEMPO = "menor_tempo"
        private const val KEY_NOME_JOGADOR = "nome_jogador"
        private const val KEY_DATA_JOGO = "data_jogo"
    }

    private var board = Array(ROWS) { IntArray(COLS) }
    private var revealed = Array(ROWS) { BooleanArray(COLS) }
    private var flagged = Array(ROWS) { BooleanArray(COLS) } // --- NOVA MATRIZ PARA BANDEIRAS ---
    private var buttons = Array(ROWS) { arrayOfNulls<Button>(COLS) }

    private lateinit var gridBoard: GridLayout
    private lateinit var tvStatus: TextView
    private lateinit var btnRestart: Button

    // --- VARIÁVEIS DE JOGO ---
    private var contadorTentativas = 0
    private var tempoSegundos = 0
    private var isPrimeiroClique = true
    private var jogoAtivo = false

    // Variáveis para as bandeiras
    private var totalMinasNoJogo = 0
    private var flagsColocadas = 0

    private val timerHandler = Handler(Looper.getMainLooper())
    private val timerRunnable = object : Runnable {
        override fun run() {
            if (jogoAtivo) {
                tempoSegundos++
                atualizarPlacar()
                timerHandler.postDelayed(this, 1000)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gridBoard = findViewById(R.id.gridBoard)
        tvStatus = findViewById(R.id.tvStatus)
        btnRestart = findViewById(R.id.btnRestart)

        btnRestart.setOnClickListener { initGame() }

        initGame()
    }

    private fun initGame() {
        board = Array(ROWS) { IntArray(COLS) }
        revealed = Array(ROWS) { BooleanArray(COLS) }
        flagged = Array(ROWS) { BooleanArray(COLS) } // Reinicia as bandeiras
        buttons = Array(ROWS) { arrayOfNulls<Button>(COLS) }

        contadorTentativas = 0
        tempoSegundos = 0
        flagsColocadas = 0
        isPrimeiroClique = true
        jogoAtivo = false

        timerHandler.removeCallbacks(timerRunnable)

        gridBoard.removeAllViews()
        gridBoard.rowCount = ROWS
        gridBoard.columnCount = COLS

        generateBoard(ROWS, COLS)
        atualizarPlacar()
        createBoardUI()
    }

    private fun atualizarPlacar() {
        val prefs = getSharedPreferences(PREF_NAME, MODE_PRIVATE)
        val menorTempo = prefs.getInt(KEY_MENOR_TEMPO, Int.MAX_VALUE)
        val nomeRecorde = prefs.getString(KEY_NOME_JOGADOR, "")
        val dataRecorde = prefs.getString(KEY_DATA_JOGO, "")

        val recordeTexto = if (menorTempo == Int.MAX_VALUE) {
            "🏆 Nenhum recorde"
        } else {
            "🏆 $nomeRecorde (${menorTempo}s - $dataRecorde)"
        }

        // Calcula as minas restantes baseando-se nas bandeiras colocadas
        val minasRestantes = totalMinasNoJogo - flagsColocadas

        tvStatus.text = getString(R.string.texto_placar, minasRestantes, contadorTentativas, tempoSegundos, recordeTexto)
    }

    private fun generateBoard(rows: Int, cols: Int) {
        val totalCells = rows * cols

        // CORREÇÃO: Usando roundToInt() do Kotlin
        totalMinasNoJogo = (totalCells * MINE_PERCENTAGE).roundToInt()

        val random = Random()
        var placedMines = 0

        while (placedMines < totalMinasNoJogo) {
            val r = random.nextInt(rows)
            val c = random.nextInt(cols)

            if (board[r][c] != -1) {
                board[r][c] = -1
                placedMines++
            }
        }

        val dRow = intArrayOf(-1, -1, -1, 0, 0, 1, 1, 1)
        val dCol = intArrayOf(-1, 0, 1, -1, 1, -1, 0, 1)

        for (r in 0 until rows) {
            for (c in 0 until cols) {
                if (board[r][c] == -1) continue

                var mineCount = 0
                for (i in 0..7) {
                    val nr = r + dRow[i]
                    val nc = c + dCol[i]
                    if (nr in 0 until rows && nc in 0 until cols && board[nr][nc] == -1) {
                        mineCount++
                    }
                }
                board[r][c] = mineCount
            }
        }
    }

    private fun createBoardUI() {
        val buttonSize = (resources.displayMetrics.widthPixels / (COLS + 1.5)).toInt()
        val colorDefault = ContextCompat.getColor(this, R.color.cell_default)

        for (r in 0 until ROWS) {
            for (c in 0 until COLS) {
                val btn = Button(this).apply {
                    layoutParams = GridLayout.LayoutParams().apply {
                        width = buttonSize
                        height = buttonSize
                        setMargins(2, 2, 2, 2)
                    }
                    backgroundTintList = ColorStateList.valueOf(colorDefault)
                    setPadding(0, 0, 0, 0)
                    textSize = 14f

                    // --- CLIQUE NORMAL: REVELA A CÉLULA ---
                    setOnClickListener { handleCellClick(r, c) }

                    // --- CLIQUE LONGO: COLOCA/REMOVE A BANDEIRA ---
                    setOnLongClickListener { handleCellLongClick(r, c) }
                }

                buttons[r][c] = btn
                gridBoard.addView(btn)
            }
        }
    }

    // --- NOVA FUNÇÃO: Lógica do clique longo (Bandeiras) ---
    private fun handleCellLongClick(r: Int, c: Int): Boolean {
        // Se já está revelado ou o jogo já acabou, ignora
        if (revealed[r][c] || (!jogoAtivo && !isPrimeiroClique)) return true

        val btn = buttons[r][c] ?: return true

        if (flagged[r][c]) {
            // Remove a bandeira
            flagged[r][c] = false
            flagsColocadas--
            btn.text = ""
        } else {
            // Se ainda houver "espaço" para bandeiras (opcional, aqui deixa colocar à vontade)
            flagged[r][c] = true
            flagsColocadas++
            btn.text = "🚩"
        }

        atualizarPlacar()
        return true // Retorna true para o Android saber que o clique longo foi consumido
    }

    private fun handleCellClick(r: Int, c: Int) {
        // --- PROTEÇÃO: Impede de clicar se houver uma bandeira ---
        if (flagged[r][c]) return

        if (revealed[r][c] || (!jogoAtivo && !isPrimeiroClique)) return

        if (isPrimeiroClique) {
            isPrimeiroClique = false
            jogoAtivo = true
            timerHandler.postDelayed(timerRunnable, 1000)
        }

        contadorTentativas++

        if (board[r][c] == -1) {
            jogoAtivo = false
            timerHandler.removeCallbacks(timerRunnable)
            revealAllMines()

            val colorExploded = ContextCompat.getColor(this, R.color.mine_exploded)
            buttons[r][c]?.apply {
                text = "💥" // Destaque na mina que explodiu
                backgroundTintList = ColorStateList.valueOf(colorExploded)
            }

            Toast.makeText(this, "Explosão! Tente novamente.", Toast.LENGTH_SHORT).show()
            disableAllButtons()
        } else if (board[r][c] == 0) {
            revealZerosCascade(r, c)
            verificarFluxoAposJogada()
        } else {
            revealSingleCell(r, c)
            verificarFluxoAposJogada()
        }
    }

    private fun verificarFluxoAposJogada() {
        if (verificarVitoria()) {
            jogoAtivo = false
            timerHandler.removeCallbacks(timerRunnable)
            Toast.makeText(this, "Parabéns! Você venceu!", Toast.LENGTH_LONG).show()
            verificarEAtualizarRecorde()
            disableAllButtons()
        } else {
            atualizarPlacar()
        }
    }

    private fun verificarVitoria(): Boolean {
        for (r in 0 until ROWS) {
            for (c in 0 until COLS) {
                if (board[r][c] != -1 && !revealed[r][c]) {
                    return false
                }
            }
        }
        return true
    }

    private fun verificarEAtualizarRecorde() {
        val prefs = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val menorTempoAtual = prefs.getInt(KEY_MENOR_TEMPO, Int.MAX_VALUE)

        if (tempoSegundos < menorTempoAtual) {
            solicitarNomeSalvarRecorde(prefs, tempoSegundos)
        } else {
            atualizarPlacar()
        }
    }

    private fun solicitarNomeSalvarRecorde(prefs: SharedPreferences, novoTempo: Int) {
        val input = EditText(this).apply {
            hint = "Digite seu nome"
            setPadding(40, 30, 40, 30)
        }

        AlertDialog.Builder(this)
            .setTitle("🏆 Novo Recorde!")
            .setMessage("Você concluiu em ${novoTempo}s!\nDigite seu nome para salvar:")
            .setView(input)
            .setCancelable(false)
            .setPositiveButton("Salvar") { _, _ ->
                val nome = input.text.toString().ifEmpty { "Anônimo" }
                val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                val dataAtual = dateFormat.format(Date())

                prefs.edit().apply {
                    putInt(KEY_MENOR_TEMPO, novoTempo)
                    putString(KEY_NOME_JOGADOR, nome)
                    putString(KEY_DATA_JOGO, dataAtual)
                    apply()
                }

                Toast.makeText(this, "Recorde salvo com sucesso!", Toast.LENGTH_SHORT).show()
                atualizarPlacar()
            }
            .show()
    }

    private fun revealSingleCell(r: Int, c: Int) {
        revealed[r][c] = true
        val btn = buttons[r][c] ?: return
        btn.isEnabled = false
        btn.text = board[r][c].toString()
        btn.setTextColor(getNumberColor(board[r][c]))

        val colorRevealed = ContextCompat.getColor(this, R.color.cell_revealed)
        btn.backgroundTintList = ColorStateList.valueOf(colorRevealed)
    }

    private fun revealZerosCascade(r: Int, c: Int) {
        if (r < 0 || r >= ROWS || c < 0 || c >= COLS) return
        if (revealed[r][c] || board[r][c] == -1) return

        // --- PROTEÇÃO: Se houver uma bandeira na célula vazia (errada), remove ela durante a cascata ---
        if (flagged[r][c]) {
            flagged[r][c] = false
            flagsColocadas--
        }

        revealed[r][c] = true
        val btn = buttons[r][c] ?: return
        btn.isEnabled = false

        if (board[r][c] == 0) {
            btn.text = ""
            val colorZero = ContextCompat.getColor(this, R.color.cell_zero)
            btn.backgroundTintList = ColorStateList.valueOf(colorZero)

            val dRow = intArrayOf(-1, -1, -1, 0, 0, 1, 1, 1)
            val dCol = intArrayOf(-1, 0, 1, -1, 1, -1, 0, 1)

            for (i in 0..7) {
                revealZerosCascade(r + dRow[i], c + dCol[i])
            }
        } else {
            btn.text = board[r][c].toString()
            btn.setTextColor(getNumberColor(board[r][c]))
            val colorRevealed = ContextCompat.getColor(this, R.color.cell_revealed)
            btn.backgroundTintList = ColorStateList.valueOf(colorRevealed)
        }
    }

    private fun revealAllMines() {
        val colorExploded = ContextCompat.getColor(this, R.color.mine_exploded)
        for (r in 0 until ROWS) {
            for (c in 0 until COLS) {
                if (board[r][c] == -1) {
                    buttons[r][c]?.apply {
                        // Se tinha uma bandeira e era mina, pode deixar a bandeira ou trocar para bomba.
                        // Vamos trocar para bomba pra ficar claro onde estavam as minas.
                        text = "💣"
                        backgroundTintList = ColorStateList.valueOf(colorExploded)
                    }
                } else if (flagged[r][c]) {
                    // Opcional: mostrar visualmente se ele colocou uma bandeira no lugar errado
                    buttons[r][c]?.text = "❌"
                }
            }
        }
    }

    private fun disableAllButtons() {
        for (r in 0 until ROWS) {
            for (c in 0 until COLS) {
                buttons[r][c]?.isEnabled = false
            }
        }
    }

    private fun getNumberColor(number: Int): Int {
        return when (number) {
            1 -> Color.parseColor("#1E88E5") // Azul
            2 -> Color.parseColor("#43A047") // Verde
            3 -> Color.parseColor("#E53935") // Vermelho
            4 -> Color.parseColor("#3949AB") // Índigo
            else -> Color.parseColor("#8E24AA") // Roxo
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        timerHandler.removeCallbacks(timerRunnable)
    }
}